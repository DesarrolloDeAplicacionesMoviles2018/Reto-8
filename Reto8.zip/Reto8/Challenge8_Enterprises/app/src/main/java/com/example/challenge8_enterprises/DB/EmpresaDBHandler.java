package com.example.challenge8_enterprises.DB;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class EmpresaDBHandler extends SQLiteOpenHelper{

    private static final String DB_NOMBRE = "empresas.db";
    private static final int DB_VERSION = 1;

    public static final String TABLA_EMPRESAS = "empresas";
    public static final String COLUMNA_ID = "id";
    public static final String COLUMNA_NOMNRE = "nombre";
    public static final String COLUMNA_SITIOWEB = "sitioweb";
    public static final String COLUMNA_TELEFONO = "telefono";
    public static final String COLUMNA_EMAIL = "email";
    public static final String COLUMNA_PRODUCTOSYSERVICIOS = "productosyservicios";
    public static final String COLUMNA_CLASIFICACION = "clasificacion";

    private static final String TABLE_CREATE = "CREATE TABLE " + TABLA_EMPRESAS + " (" + COLUMNA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMNA_NOMNRE + " TEXT, " + COLUMNA_SITIOWEB + " TEXT, " + COLUMNA_TELEFONO + " TEXT, " + COLUMNA_EMAIL + " TEXT, " + COLUMNA_PRODUCTOSYSERVICIOS + " TEXT, " + COLUMNA_CLASIFICACION + " TEXT " + ")";

    public EmpresaDBHandler(Context context){
        super(context, DB_NOMBRE,null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase dataBase){
        dataBase.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase dataBase, int oldVersion, int newVersion){
        dataBase.execSQL("DROP TABLE IF EXISTS " + TABLA_EMPRESAS);
        dataBase.execSQL(TABLE_CREATE);
    }
}