package com.example.challenge8_enterprises;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.challenge8_enterprises.DB.Operaciones;
import com.example.challenge8_enterprises.Model.Empresa;

public class MainActivity extends AppCompatActivity{
    private Button addEnterpriseButton;
    private Button editEnterpriseButton;
    private Button deleteEnterpriseButton;
    private Button viewAllEnterpriseButton;
    private Button viewEnterpriseByIdButton;
    private Button deleteAllEnterprisesButton;
    private Button advancedSearchButton;
    private Operaciones enterpriseOperations;
    private static final String EXTRA_ENTERPRISE_ID = "com.example.enterpriseId";
    private static final String EXTRA_ADD_UPDATE = "com.example.add_update";

    private SharedPreferences preferences;
    private String nameConsult, classificationConsult;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addEnterpriseButton = (Button) findViewById(R.id.button_add_enterprise);
        editEnterpriseButton = (Button) findViewById(R.id.button_edit_enterprise);
        deleteEnterpriseButton = (Button) findViewById(R.id.button_delete_enterprise);
        viewAllEnterpriseButton = (Button)findViewById(R.id.button_view_enterprises);
        viewEnterpriseByIdButton = (Button)findViewById(R.id.button_view_enterprise_by_id);
        deleteAllEnterprisesButton = (Button)findViewById(R.id.button_delete_all_enterprises);
        advancedSearchButton = (Button)findViewById(R.id.button_advanced_search);
        enterpriseOperations = new Operaciones(MainActivity.this);

        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        nameConsult = preferences.getString("name", "");
        classificationConsult = preferences.getString("classification", "");

        addEnterpriseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(MainActivity.this, AddUpdateEnterprise.class);
                i.putExtra(EXTRA_ADD_UPDATE,"Add");
                startActivity(i);
            }
        });

        editEnterpriseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                getEnterpriseIdAndUpdateEnterprise();
            }
        });

        viewEnterpriseByIdButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                getEnterpriseIdAndShowEnterprise();
            }
        });

        deleteEnterpriseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                getEnterpriseIdAndRemoveEnterprise();
            }
        });

        viewAllEnterpriseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(MainActivity.this, ViewAllEnterprises.class);
                startActivity(i);
            }
        });

        deleteAllEnterprisesButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                removeAllEnterprises();
            }
        });

        advancedSearchButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                getEnterpriseSearch();
                //Intent i = new Intent(MainActivity.this, ViewEnterprises.class);
                //startActivity(i);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.enterprise_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if(id == R.id.menu_item_settings){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void getEnterpriseIdAndUpdateEnterprise(){
        LayoutInflater li = LayoutInflater.from(this);
        View getEmpIdView = li.inflate(R.layout.dialog_get_enterprise_id, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setView(getEmpIdView);
        final EditText userInput = (EditText) getEmpIdView.findViewById(R.id.editTextDialogUserInput);

        alertDialogBuilder.setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id){
                Intent i = new Intent(MainActivity.this, AddUpdateEnterprise.class);
                i.putExtra(EXTRA_ADD_UPDATE, "Update");
                i.putExtra(EXTRA_ENTERPRISE_ID, Long.parseLong(userInput.getText().toString()));
                startActivity(i);
            }
        }).create().show();
    }

    public void removeAllEnterprises(){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("[All] Sure?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id){
                //enterpriseOperations = new EnterpriseOperations(MainActivity.this);
                enterpriseOperations.removeAllEnterprises();
                Toast t = Toast.makeText(MainActivity.this,"Enterprise removed successfully!", Toast.LENGTH_SHORT);
                t.show();
            }
        }).setNegativeButton("No", null);
        AlertDialog dialog = builder.create();
        ((AlertDialog) dialog).show();
    }

    public void getEnterpriseIdAndRemoveEnterprise(){
        LayoutInflater li = LayoutInflater.from(this);
        View getEmpIdView = li.inflate(R.layout.dialog_get_enterprise_id, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setView(getEmpIdView);
        final EditText userInput = (EditText) getEmpIdView.findViewById(R.id.editTextDialogUserInput);

        alertDialogBuilder.setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id){
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("Sure?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int id){
                        //enterpriseOperations = new EnterpriseOperations(MainActivity.this);
                        enterpriseOperations.removeEnterprise(enterpriseOperations.getEnterprise(Long.parseLong(userInput.getText().toString())));
                        Toast t = Toast.makeText(MainActivity.this,"Enterprise removed successfully!", Toast.LENGTH_SHORT);
                        t.show();
                    }
                }).setNegativeButton("No", null);
                dialog = builder.create();
                ((AlertDialog) dialog).show();
            }
        }).create().show();
    }

    public void getEnterpriseIdAndShowEnterprise(){
        LayoutInflater li = LayoutInflater.from(this);
        View getEmpIdView = li.inflate(R.layout.dialog_get_enterprise_id, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setView(getEmpIdView);
        final EditText userInput = (EditText) getEmpIdView.findViewById(R.id.editTextDialogUserInput);

        alertDialogBuilder.setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id){
                //enterpriseOperations = new EnterpriseOperations(MainActivity.this);
                Empresa e = enterpriseOperations.getEnterprise(Long.parseLong(userInput.getText().toString()));
                Toast t = Toast.makeText(MainActivity.this,"Enterprise consulted successfully!" + e, Toast.LENGTH_SHORT);
                t.show();
            }
        }).create().show();
    }

    public void getEnterpriseSearch(){
        LayoutInflater li = LayoutInflater.from(this);
        View getEmpIdView = li.inflate(R.layout.dialog_get_enterprise_filter, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setView(getEmpIdView);
        final EditText userInput = (EditText) getEmpIdView.findViewById(R.id.edit_text_name_search);
        final Spinner userInput2 = (Spinner) getEmpIdView.findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.classification_enterprise, android.R.layout.simple_spinner_item);
        //Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Apply the adapter to the spinner
        userInput2.setAdapter(adapter);

        alertDialogBuilder.setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id){

                SharedPreferences.Editor editorPreferences = preferences.edit();
                editorPreferences.putString("name", userInput.getText().toString());
                editorPreferences.putString("classification", userInput2.getSelectedItem().toString());
                editorPreferences.commit();

                //List<Enterprise> enterprise = enterpriseOperations.getAllEnterpriseSelected(userInput.getText().toString(), userInput2.getSelectedItem().toString());
                //Toast t = Toast.makeText(MainActivity.this,"Enterprise consulted successfully!", Toast.LENGTH_SHORT);
                //t.show();
                Intent i = new Intent(MainActivity.this, ViewEnterprises.class);
                startActivity(i);
            }
        }).create().show();
    }

    @Override
    protected void onResume(){
        super.onResume();
        enterpriseOperations.open();
    }

    @Override
    protected void onPause(){
        super.onPause();
        enterpriseOperations.close();
    }
}