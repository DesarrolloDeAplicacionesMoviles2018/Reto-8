package com.example.challenge8_enterprises;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import com.example.challenge8_enterprises.DB.Operaciones;
import com.example.challenge8_enterprises.Model.Empresa;

import java.util.List;

public class ViewAllEnterprises extends ListActivity{
    private Operaciones operaciones;
    List<Empresa> empresas;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_enterprises);
        operaciones = new Operaciones(this);
        operaciones.open();
        empresas = operaciones.getAllEnterprises();
        System.out.println(empresas);
        operaciones.close();
        ArrayAdapter<Empresa> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, empresas);
        setListAdapter(adapter);
    }
}