package com.example.challenge8_enterprises.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.challenge8_enterprises.Model.Empresa;

import java.util.ArrayList;
import java.util.List;

public class Operaciones {
    public static final String LOGTAG = "ENTERPRISE_SYSTEM";

    SQLiteOpenHelper dataBaseHandler;
    SQLiteDatabase dataBase;

    private static final String[] allColumns = {EmpresaDBHandler.COLUMNA_ID, EmpresaDBHandler.COLUMNA_NOMNRE, EmpresaDBHandler.COLUMNA_SITIOWEB, EmpresaDBHandler.COLUMNA_TELEFONO, EmpresaDBHandler.COLUMNA_EMAIL, EmpresaDBHandler.COLUMNA_PRODUCTOSYSERVICIOS, EmpresaDBHandler.COLUMNA_CLASIFICACION};

    public Operaciones(Context context){
        dataBaseHandler = new EmpresaDBHandler(context);
    }

    public void open(){
        Log.i(LOGTAG,"Database Opened");
        dataBase = dataBaseHandler.getWritableDatabase();
    }
    public void close(){
        Log.i(LOGTAG, "Database Closed");
        dataBaseHandler.close();
    }

    //Create Method
    public Empresa addEnterprise(Empresa Enterprise){
        ContentValues values = new ContentValues();
        values.put(EmpresaDBHandler.COLUMNA_NOMNRE, Enterprise.getNombre());
        values.put(EmpresaDBHandler.COLUMNA_SITIOWEB, Enterprise.getSitioweb());
        values.put(EmpresaDBHandler.COLUMNA_TELEFONO, Enterprise.getTelefono());
        values.put(EmpresaDBHandler.COLUMNA_EMAIL, Enterprise.getEmail());
        values.put(EmpresaDBHandler.COLUMNA_PRODUCTOSYSERVICIOS, Enterprise.getProductosyservicios());
        values.put(EmpresaDBHandler.COLUMNA_CLASIFICACION, Enterprise.getClasificacion());
        long enterpriseId = dataBase.insert(EmpresaDBHandler.TABLA_EMPRESAS,null, values);
        Enterprise.setId(enterpriseId);
        return Enterprise;

    }

    //Read Method (Single Object)
    public Empresa getEnterprise(long enterpriseId){
        Cursor cursor = dataBase.query(EmpresaDBHandler.TABLA_EMPRESAS, allColumns,EmpresaDBHandler.COLUMNA_ID + "=?", new String[]{String.valueOf(enterpriseId)},null,null,null,null);
        if(cursor != null){
            cursor.moveToFirst();
        }
        Empresa enterprise = new Empresa(Long.parseLong(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6));
        return enterprise;
    }
    //Read Method (Multiple Object)
    public List<Empresa> getAllEnterprises(){
        Cursor cursor = dataBase.query(EmpresaDBHandler.TABLA_EMPRESAS, allColumns,null,null,null,null,null);
        List<Empresa> enterprises = new ArrayList<>();
        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                Empresa enterprise = new Empresa();
                enterprise.setId(cursor.getLong(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_ID)));
                enterprise.setNombre(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_NOMNRE)));
                enterprise.setSitioweb(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_SITIOWEB)));
                enterprise.setTelefono(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_TELEFONO)));
                enterprise.setEmail(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_EMAIL)));
                enterprise.setProductosyservicios(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_PRODUCTOSYSERVICIOS)));
                enterprise.setClasificacion(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_CLASIFICACION)));
                enterprises.add(enterprise);
            }
        }
        return enterprises;
    }
    //Read Method (Multiple Object)
    public List<Empresa> getAllEnterpriseSelected(String name, String classification){
        Cursor cursor = dataBase.query(EmpresaDBHandler.TABLA_EMPRESAS, allColumns,null,null,null,null,null);
        if(name.equals("") == false && classification.equals("") == false){
            cursor = dataBase.query(EmpresaDBHandler.TABLA_EMPRESAS, allColumns, EmpresaDBHandler.COLUMNA_NOMNRE + "=?" + " AND " + EmpresaDBHandler.COLUMNA_CLASIFICACION + "=?", new String[]{String.valueOf(name), String.valueOf(classification)}, null, null, null, null);
        }else if(name.equals("") == true){
            cursor = dataBase.query(EmpresaDBHandler.TABLA_EMPRESAS, allColumns, EmpresaDBHandler.COLUMNA_CLASIFICACION + "=?", new String[]{String.valueOf(classification)}, null, null, null, null);
        }else if(classification.equals("") == true){
            cursor = dataBase.query(EmpresaDBHandler.TABLA_EMPRESAS, allColumns, EmpresaDBHandler.COLUMNA_NOMNRE+ "=?", new String[]{String.valueOf(name)}, null, null, null, null);
        }
        List<Empresa> enterprises = new ArrayList<>();
        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                Empresa enterprise = new Empresa();
                enterprise.setId(cursor.getLong(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_ID)));
                enterprise.setNombre(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_NOMNRE)));
                enterprise.setSitioweb(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_SITIOWEB)));
                enterprise.setTelefono(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_TELEFONO)));
                enterprise.setEmail(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_EMAIL)));
                enterprise.setProductosyservicios(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_PRODUCTOSYSERVICIOS)));
                enterprise.setClasificacion(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMNA_CLASIFICACION)));
                enterprises.add(enterprise);
            }
        }
        return enterprises;
    }

    //Update Method
    public int updateEnterprise(Empresa enterprise){
        ContentValues values = new ContentValues();
        values.put(EmpresaDBHandler.COLUMNA_NOMNRE, enterprise.getNombre());
        values.put(EmpresaDBHandler.COLUMNA_SITIOWEB, enterprise.getSitioweb());
        values.put(EmpresaDBHandler.COLUMNA_TELEFONO, enterprise.getTelefono());
        values.put(EmpresaDBHandler.COLUMNA_EMAIL, enterprise.getEmail());
        values.put(EmpresaDBHandler.COLUMNA_PRODUCTOSYSERVICIOS, enterprise.getProductosyservicios());
        values.put(EmpresaDBHandler.COLUMNA_CLASIFICACION, enterprise.getClasificacion());
        return dataBase.update(EmpresaDBHandler.TABLA_EMPRESAS, values,EmpresaDBHandler.COLUMNA_ID + "=?", new String[]{String.valueOf(enterprise.getId())});
    }

    //Delete Method (Single Object)
    public void removeEnterprise(Empresa enterprise){
        dataBase.delete(EmpresaDBHandler.TABLA_EMPRESAS,EmpresaDBHandler.COLUMNA_ID + "=" + enterprise.getId(),null);
    }
    //Delete Method (Multiple Object)
    public void removeAllEnterprises(){
        dataBase.delete(EmpresaDBHandler.TABLA_EMPRESAS,null,null);
    }
}