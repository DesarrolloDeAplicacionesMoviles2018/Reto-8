package com.example.challenge8_enterprises.Model;

public class Empresa{

    private long id;
    private String nombre;
    private String sitioweb;
    private String telefono;
    private String email;
    private String productosyservicios;
    private String clasificacion;

    public Empresa(long id, String nombre, String sitioweb, String telefono, String email,
                   String productosyservicios, String clasificacion){
        this.id = id;
        this.nombre = nombre;
        this.sitioweb = sitioweb;
        this.telefono = telefono;
        this.email = email;
        this.productosyservicios = productosyservicios;
        this.clasificacion = clasificacion;
    }

    public Empresa(){

    }

    public String toString(){
        return "Id: " + this.getId() + "\nNombre: " + this.getNombre() + "\nWebsite URL: " + this.getSitioweb() + "\nTelefono: " + this.getTelefono() + "\nEmail: " + this.getEmail() + "\nProductos y servicios: " + this.getProductosyservicios() + "\nClasificacion: " + this.getClasificacion();
    }

    public String getSitioweb() {
        return sitioweb;
    }

    public void setSitioweb(String sitioweb) {
        this.sitioweb = sitioweb;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProductosyservicios() {
        return productosyservicios;
    }

    public void setProductosyservicios(String productosyservicios) {
        this.productosyservicios = productosyservicios;
    }

    public String getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }
}