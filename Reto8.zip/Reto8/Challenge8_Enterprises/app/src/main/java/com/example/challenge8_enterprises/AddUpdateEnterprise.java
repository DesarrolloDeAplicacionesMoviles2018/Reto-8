package com.example.challenge8_enterprises;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.challenge8_enterprises.DB.Operaciones;
import com.example.challenge8_enterprises.Model.Empresa;

public class AddUpdateEnterprise extends AppCompatActivity {
    private static final String EXTRA_EMP_ID = "com.example.enterpriseId";
    private static final String EXTRA_ADD_UPDATE = "com.example.add_update";
    private RadioGroup radioGroup;
    private RadioButton consultingRadioButton, customDevelopmentRadioButton, softwareFactoryRadioButton;
    private EditText nameEditText;
    private EditText websiteEditText;
    private EditText telephoneEditText;
    private EditText emailEditText;
    private EditText productsServicesEditText;
    private Button addUpdateButton;
    private Empresa newEnterprise;
    private Empresa oldEnterprise;
    private String mode;
    private long enterpriseId;
    private Operaciones enterpriseData;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_update_enterprise);
        newEnterprise = new Empresa();
        oldEnterprise = new Empresa();
        nameEditText = (EditText)findViewById(R.id.edit_text_name);
        websiteEditText = (EditText)findViewById(R.id.edit_text_website);
        telephoneEditText = (EditText)findViewById(R.id.edit_text_telephone);
        emailEditText = (EditText)findViewById(R.id.edit_text_website);
        productsServicesEditText = (EditText)findViewById(R.id.edit_text_productsservices);

        radioGroup = (RadioGroup) findViewById(R.id.radio_classification);
        consultingRadioButton = (RadioButton) findViewById(R.id.radio_consulting);
        customDevelopmentRadioButton = (RadioButton) findViewById(R.id.radio_customdevelopment);
        softwareFactoryRadioButton = (RadioButton) findViewById(R.id.radio_softwarefactory);

        addUpdateButton = (Button)findViewById(R.id.button_add_update_enterprise);
        enterpriseData = new Operaciones(this);
        enterpriseData.open();

        mode = getIntent().getStringExtra(EXTRA_ADD_UPDATE);
        if(mode.equals("Update")){
            addUpdateButton.setText("Update Enterprise");
            enterpriseId = getIntent().getLongExtra(EXTRA_EMP_ID,0);
            initializeEnterprise(enterpriseId);
        }

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId){
                if(checkedId == R.id.radio_consulting){
                    newEnterprise.setClasificacion("Consulting");
                    if(mode.equals("Update")){
                        oldEnterprise.setClasificacion("Consulting");
                    }
                }else if(checkedId == R.id.radio_customdevelopment){
                    newEnterprise.setClasificacion("Custom Development");
                    if(mode.equals("Update")){
                        oldEnterprise.setClasificacion("Custom Development");
                    }
                }else if(checkedId == R.id.radio_softwarefactory){
                    newEnterprise.setClasificacion("Software Factory");
                    if(mode.equals("Update")){
                        oldEnterprise.setClasificacion("Software Factory");
                    }
                }
            }
        });

        addUpdateButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(mode.equals("Add")){
                    newEnterprise.setNombre(nameEditText.getText().toString());
                    newEnterprise.setSitioweb(websiteEditText.getText().toString());
                    newEnterprise.setTelefono(telephoneEditText.getText().toString());
                    newEnterprise.setEmail(emailEditText.getText().toString());
                    newEnterprise.setProductosyservicios(productsServicesEditText.getText().toString());

                    if(radioGroup.getCheckedRadioButtonId() == R.id.radio_consulting){
                        newEnterprise.setClasificacion("Consulting");
                    }else if(radioGroup.getCheckedRadioButtonId() == R.id.radio_customdevelopment){
                        newEnterprise.setClasificacion("Custom Development");
                    }else if(radioGroup.getCheckedRadioButtonId() == R.id.radio_softwarefactory){
                        newEnterprise.setClasificacion("Software Factory");
                    }

                    enterpriseData.addEnterprise(newEnterprise);
                    Toast t = Toast.makeText(AddUpdateEnterprise.this, "Enterprise " + newEnterprise.getNombre() + " has been added successfully !", Toast.LENGTH_SHORT);
                    t.show();
                    Intent i = new Intent(AddUpdateEnterprise.this,MainActivity.class);
                    startActivity(i);
                }else{
                    oldEnterprise.setNombre(nameEditText.getText().toString());
                    oldEnterprise.setSitioweb(websiteEditText.getText().toString());
                    oldEnterprise.setTelefono(telephoneEditText.getText().toString());
                    oldEnterprise.setEmail(emailEditText.getText().toString());
                    oldEnterprise.setProductosyservicios(productsServicesEditText.getText().toString());
                    enterpriseData.updateEnterprise(oldEnterprise);
                    Toast t = Toast.makeText(AddUpdateEnterprise.this, "Employee "+ oldEnterprise.getNombre() + " has been updated successfully !", Toast.LENGTH_SHORT);
                    t.show();
                    Intent i = new Intent(AddUpdateEnterprise.this,MainActivity.class);
                    startActivity(i);
                }
            }
        });
    }

    private void initializeEnterprise(long enterpriseId){
        oldEnterprise = enterpriseData.getEnterprise(enterpriseId);
        nameEditText.setText(oldEnterprise.getNombre());
        websiteEditText.setText(oldEnterprise.getSitioweb());
        telephoneEditText.setText(oldEnterprise.getTelefono());
        emailEditText.setText(oldEnterprise.getEmail());
        productsServicesEditText.setText(oldEnterprise.getProductosyservicios());
        radioGroup.check(oldEnterprise.getClasificacion().equals("Consulting") ? R.id.radio_consulting : (oldEnterprise.getClasificacion().equals("Custom Development") ? R.id.radio_customdevelopment : R.id.radio_softwarefactory));
    }
}