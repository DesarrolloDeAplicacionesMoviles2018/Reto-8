package com.example.challenge8_enterprises;

import android.app.ListActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.ArrayAdapter;

import com.example.challenge8_enterprises.DB.Operaciones;
import com.example.challenge8_enterprises.Model.Empresa;

import java.util.List;

public class ViewEnterprises extends ListActivity {
    private Operaciones enterpriseOperations;
    private SharedPreferences preferences;
    private String param1, param2;
    List<Empresa> employees;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_enterprises);

        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        param1 = preferences.getString("name", "");
        param2 = preferences.getString("classification", "");

        enterpriseOperations = new Operaciones(this);
        enterpriseOperations.open();
        System.out.println(param1 + "-" + param1.equals(""));
        System.out.println(param2 + "-" + param2.equals(""));
        employees = enterpriseOperations.getAllEnterpriseSelected(this.getParam1(), this.getParam2());
        enterpriseOperations.close();
        ArrayAdapter<Empresa> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, employees);
        setListAdapter(adapter);
    }

    public String getParam1(){
        return this.param1;
    }
    public void setParam1(String param1){
        this.param1 = param1;
    }
    public String getParam2(){
        return this.param2;
    }
    public void setParam2(String param2){
        this.param2 = param2;
    }
}